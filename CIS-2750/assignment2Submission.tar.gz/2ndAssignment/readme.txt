/********************
Ian Cross
0911085
icross@mail.uoguelph.ca
CIS*2750
Assignment2
********************/

to work the menu you have to press enter after your key, sorry.

viewing all streams is kinda broken

Reordering, Page up, and Page down are not implemented, pressing these buttons will just not do anything


I'm sure you remember this course, please be gentle :)
