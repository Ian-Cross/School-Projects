
Code from:
https://www.fixstars.com/en/opencl/book/OpenCLProgrammingBook/first-opencl-program/

Updated to use OpenCL 2.2

