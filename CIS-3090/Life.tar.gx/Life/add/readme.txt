
Code from the website:
http://www.drdobbs.com/parallel/a-gentle-introduction-to-opencl/231002854?pgno=1

Updated for OpenCL version 2.2

