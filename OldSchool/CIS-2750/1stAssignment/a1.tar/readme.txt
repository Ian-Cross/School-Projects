/********************
Ian Cross
0911085
icross@mail.uoguelph.ca
CIS2750
Assignment1
********************/

*****Things that probably don't work*****

-Custom types
    if a function tries to return a struct or something like that, it'll likely screw up the whole thing

-class function in a function
    unfortunately, if a function in a class tries to call another function in that class, (maybe any other
    class for that matter), if will be undefined because the name was not changed over.

-Global classes
    if you're trying to make a global class variable, it'll just ignore it

-Comments
    if a comment isn't in a function it will get erased... oops

Please be gentle :) Remember how you felt going through this class.
